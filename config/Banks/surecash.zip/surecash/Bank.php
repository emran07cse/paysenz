<?php

return [
    'api_url' => 'https://www.bkashcluster.com:9081/dreamwave/merchant/trxcheck/sendmsg',
	
    'msisdn' => '01304034838',
    'user' => 'PAYSENZLIMITRM24232',
    'pass' => 'bYnqedd5^'
];